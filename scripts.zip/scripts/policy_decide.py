#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY_PATH = ROOT / "infra" / "policy.json"

def load_policy() -> dict:
    return json.loads(POLICY_PATH.read_text(encoding="utf-8"))

def match_when(when: dict, task: str, text: str) -> bool:
    if "task" in when and when["task"] != task:
        return False
    if "text_min_chars" in when and len(text) < int(when["text_min_chars"]):
        return False
    return True

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True, choices=["plan", "plan_web", "other"])
    ap.add_argument("--text", default=None)
    ap.add_argument("--text-file", default=None)
    args = ap.parse_args()

    text = ""
    if args.text_file:
        text = Path(args.text_file).read_text(encoding="utf-8", errors="replace")
    elif args.text is not None:
        text = args.text
    else:
        text = ""

    pol = load_policy()
    out = dict(pol.get("defaults", {}))
    applied = []

    for rule in pol.get("rules", []):
        when = rule.get("when", {})
        if match_when(when, args.task, text):
            out.update(rule.get("set", {}))
            applied.append(rule.get("name", "unnamed_rule"))

    decision = {
        "task": args.task,
        "model": out.get("model"),
        "timeout_s": int(out.get("timeout_s", 60)),
        "max_attempts": int(out.get("max_attempts", 2)),
        "json_only": bool(out.get("json_only", False)),
        "applied_rules": applied,
        "policy_version": pol.get("version", 1)
    }

    print(json.dumps(decision, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
