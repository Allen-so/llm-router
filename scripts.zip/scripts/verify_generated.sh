#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1

LATEST_PTR="artifacts/runs/LATEST"

resolve_latest_run() {
  # Prefer symlink
  if [ -L "$LATEST_PTR" ]; then
    readlink -f "$LATEST_PTR"
    return 0
  fi
  # If it's a file containing a path
  if [ -f "$LATEST_PTR" ]; then
    local p
    p="$(cat "$LATEST_PTR" 2>/dev/null || true)"
    if [ -n "${p:-}" ] && [ -d "$p" ]; then
      (cd "$p" && pwd)
      return 0
    fi
  fi
  # Fallback: newest run_*
  local newest
  newest="$(ls -1dt artifacts/runs/run_* 2>/dev/null | head -n 1 || true)"
  if [ -n "${newest:-}" ] && [ -d "$newest" ]; then
    (cd "$newest" && pwd)
    return 0
  fi
  return 1
}

RUN_DIR="$(resolve_latest_run)"
RUN_ID="$(basename "$RUN_DIR")"

pick_generated_dir() {
  local d
  # Prefer matching .generated_from_run
  for d in apps/generated/*; do
    [ -d "$d" ] || continue
    [ -f "$d/.generated_from_run" ] || continue
    if grep -q "$RUN_ID" "$d/.generated_from_run" 2>/dev/null; then
      (cd "$d" && pwd)
      return 0
    fi
  done
  # Fallback: newest generated dir
  local newest
  newest="$(ls -1dt apps/generated/* 2>/dev/null | head -n 1 || true)"
  if [ -n "${newest:-}" ] && [ -d "$newest" ]; then
    (cd "$newest" && pwd)
    return 0
  fi
  return 1
}

GEN_DIR="$(pick_generated_dir)"

LOG="$RUN_DIR/verify.log"
SUMMARY="$RUN_DIR/verify_summary.json"

echo "[verify] run_dir=$RUN_DIR" | tee "$LOG"
echo "[verify] gen_dir=$GEN_DIR" | tee -a "$LOG"
echo "[verify] ts=$(date -Is)" | tee -a "$LOG"
echo | tee -a "$LOG"

cd "$GEN_DIR" || exit 1

python3 -V | tee -a "$LOG"

# Discover package (src/<pkg>)
PKG="$(python3 - <<'PY'
import pathlib
src = pathlib.Path("src")
if not src.is_dir():
    print("")
    raise SystemExit(0)
cands = []
for p in src.iterdir():
    if p.is_dir() and (p / "__init__.py").exists():
        cands.append(p.name)
print(cands[0] if cands else "")
PY
)"

if [ -z "${PKG:-}" ]; then
  echo "[fail] cannot find src/<pkg> (missing src/ or __init__.py)" | tee -a "$LOG"
  cat > "$SUMMARY" <<JSON
{"ok": false, "reason": "cannot_find_package", "run_id": "$RUN_ID"}
JSON
  exit 1
fi

echo "[info] pkg=$PKG" | tee -a "$LOG"

# Ensure python -m <pkg> works by adding __main__.py when cli.py exists
MAIN_PY="src/$PKG/__main__.py"
CLI_PY="src/$PKG/cli.py"

if [ ! -f "$MAIN_PY" ] && [ -f "$CLI_PY" ]; then
  cat > "$MAIN_PY" <<PY
from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
PY
  echo "[fix] created $MAIN_PY to support: python -m $PKG" | tee -a "$LOG"
fi

# Create venv (inside generated dir; generated is gitignored anyway)
VENV_DIR=".venv_verify"
if [ -d "$VENV_DIR" ]; then
  rm -rf "$VENV_DIR"
fi

python3 -m venv "$VENV_DIR" | tee -a "$LOG"
# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

python -V | tee -a "$LOG"
python -m pip -V | tee -a "$LOG"

# Install editable
python -m pip install -e . | tee -a "$LOG"

# Try to find console scripts in pyproject.toml
SCRIPT_NAME="$(python - <<'PY'
import pathlib, re
p = pathlib.Path("pyproject.toml")
if not p.exists():
    print("")
    raise SystemExit(0)
txt = p.read_text(encoding="utf-8", errors="ignore")
# naive but robust enough: find first script key under [project.scripts]
m = re.search(r'(?ms)^\[project\.scripts\]\s*(.+?)(^\[|\Z)', txt)
if not m:
    print("")
    raise SystemExit(0)
block = m.group(1)
for line in block.splitlines():
    line=line.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    k = line.split("=",1)[0].strip()
    if k:
        print(k)
        break
else:
    print("")
PY
)"

ENTRY_CMD=""
if [ -n "${SCRIPT_NAME:-}" ]; then
  ENTRY_CMD="${SCRIPT_NAME} --help"
else
  # Prefer python -m <pkg>
  ENTRY_CMD="python -m ${PKG} --help"
fi

echo "[run] $ENTRY_CMD" | tee -a "$LOG"
set +e
bash -lc "$ENTRY_CMD" >>"$LOG" 2>&1
RC=$?
set -e

if [ $RC -ne 0 ]; then
  echo "[fail] entrypoint failed rc=$RC" | tee -a "$LOG"
  # last fallback: python -m <pkg>.cli --help (if exists)
  if [ -f "$CLI_PY" ]; then
    echo "[fallback] python -m ${PKG}.cli --help" | tee -a "$LOG"
    set +e
    bash -lc "python -m ${PKG}.cli --help" >>"$LOG" 2>&1
    RC2=$?
    set -e
    if [ $RC2 -ne 0 ]; then
      cat > "$SUMMARY" <<JSON
{"ok": false, "run_id": "$RUN_ID", "pkg": "$PKG", "entry_cmd": "$ENTRY_CMD", "rc": $RC}
JSON
      exit 1
    fi
    ENTRY_CMD="python -m ${PKG}.cli --help"
    RC=0
  else
    cat > "$SUMMARY" <<JSON
{"ok": false, "run_id": "$RUN_ID", "pkg": "$PKG", "entry_cmd": "$ENTRY_CMD", "rc": $RC}
JSON
    exit 1
  fi
fi

cat > "$SUMMARY" <<JSON
{"ok": true, "run_id": "$RUN_ID", "pkg": "$PKG", "entry_cmd": "$ENTRY_CMD"}
JSON

echo "[ok] generated project smoke test passed" | tee -a "$LOG"
