#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1

# Load WSL-native node/npm (nvm)
source "$ROOT/scripts/load_node.sh" || true

LATEST_PTR="artifacts/runs/LATEST"

resolve_latest_run() {
  if [ -L "$LATEST_PTR" ]; then
    readlink -f "$LATEST_PTR"
    return 0
  fi
  if [ -f "$LATEST_PTR" ]; then
    local p
    p="$(cat "$LATEST_PTR" 2>/dev/null || true)"
    if [ -n "${p:-}" ] && [ -d "$p" ]; then
      (cd "$p" && pwd)
      return 0
    fi
  fi
  local newest
  newest="$(ls -1dt artifacts/runs/run_* 2>/dev/null | head -n 1 || true)"
  [ -n "${newest:-}" ] && [ -d "$newest" ] && (cd "$newest" && pwd) && return 0
  return 1
}

RUN_DIR="$(resolve_latest_run || true)"
if [ -z "${RUN_DIR:-}" ] || [ ! -d "$RUN_DIR" ]; then
  echo "[fail] cannot resolve latest run dir" >&2
  exit 2
fi

RUN_ID="$(basename "$RUN_DIR")"
LOG="$RUN_DIR/verify_web.log"

echo "[verify_web] run_dir=$RUN_DIR" | tee -a "$LOG"
echo "[verify_web] ts=$(date -Iseconds)" | tee -a "$LOG"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "[fail] node/npm not installed" | tee -a "$LOG"
  exit 2
fi

echo "$(node -v)" | tee -a "$LOG"
echo "$(npm -v)" | tee -a "$LOG"

# 1) Try locate gen_dir by matching run_dir in marker
GEN_DIR=""
for d in apps/generated/*; do
  [ -d "$d" ] || continue
  [ -f "$d/.generated_from_run" ] || continue
  grep -q '^project_type=nextjs_site$' "$d/.generated_from_run" 2>/dev/null || continue
  if grep -q "^run_dir=$RUN_DIR\$" "$d/.generated_from_run" 2>/dev/null; then
    GEN_DIR="$d"
    break
  fi
done

# 2) Fallback: compute gen_dir from plan hash (for idempotent scaffold)
if [ -z "${GEN_DIR:-}" ]; then
  PLAN_PATH="$RUN_DIR/plan.web.json"
  if [ ! -f "$PLAN_PATH" ]; then
    echo "[fail] missing plan.web.json in run dir" | tee -a "$LOG"
    exit 2
  fi

  GEN_DIR="$(RUN_DIR="$RUN_DIR" python3 - <<'PY'
import json, hashlib, re, pathlib, os
run_dir = pathlib.Path(os.environ["RUN_DIR"])
plan = json.loads((run_dir/"plan.web.json").read_text(encoding="utf-8"))
s = json.dumps(plan, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
h = hashlib.sha256(s.encode("utf-8")).hexdigest()[:12]
name = (plan.get("name") or "site").strip().lower().replace("_","-").replace(" ","-")
name = re.sub(r"[^a-z0-9-]+","-",name)
name = re.sub(r"-{2,}","-",name).strip("-") or "site"
print(f"apps/generated/{name}__{h}")
PY
)"
  echo "[info] gen_dir fallback by plan hash: $GEN_DIR" | tee -a "$LOG"
fi

if [ -z "${GEN_DIR:-}" ] || [ ! -d "$GEN_DIR" ]; then
  echo "[fail] cannot find generated nextjs_site dir for run=$RUN_ID" | tee -a "$LOG"
  exit 2
fi

echo "[verify_web] gen_dir=$GEN_DIR" | tee -a "$LOG"

cd "$GEN_DIR" || exit 1

if [ -f package-lock.json ]; then
  echo "[run] npm ci" | tee -a "$LOG"
  npm ci 2>&1 | tee -a "$LOG"
else
  echo "[run] npm install" | tee -a "$LOG"
  npm install 2>&1 | tee -a "$LOG"
fi

echo "[run] npm run build" | tee -a "$LOG"
npm run build 2>&1 | tee -a "$LOG"

echo "[ok] web build passed" | tee -a "$LOG"
